/*
 * 
 * Author: Tommy
 * 
 * Created on 27 March 2022, 18:25
 */
#include "allcode_api.h"
void DanceFinal();
void LineCounting();
void LineModulus();
void LeftWall();
void RightWall();
void Moving();
void DistanceCalc();

unsigned short ls1Rblack = 0; //line sensor values for black and white strips
unsigned short ls1Rwhite = 0;
unsigned short ls2Lblack = 0;
unsigned short ls2Lwhite = 0;
unsigned short botX = 1;
unsigned short botY = 0;
unsigned long startTime;
static int botstate = 1;
char direction;
int directioncount = 1;
int TotalLines;
int distance;
int totalDistance;
int turncount = 0;

int main(void) {
    FA_RobotInit();         
    FA_LCDBacklight(50);   
    FA_LCDPrint("Hello there", 11, 20, 25, FONT_NORMAL, LCD_OPAQUE);   
    FA_DelayMillis(1000);
    FA_LCDClear();

    while(1){
        
        switch(botstate){
            case 1:
                //FA_SetMotors(50,46);// drive forward
                //FA_SetMotors(23,23);// half speed
                FA_SetMotors(24,22);
                FA_LCDNumber(TotalLines, 20, 25, FONT_NORMAL, LCD_OPAQUE);
                LineCounting();
                break;
            case 2:
                RightWall();
                break;
            case 3:
                LeftWall();
                break;
            case 4:
                DanceFinal();
                break;
            case 0:
                FA_LCDPrint("The End", 7, 20, 25, FONT_NORMAL, LCD_OPAQUE);
                break;
        }
        if(FA_ReadSwitch(1) == 1){ //right button to start dance and display (FA_ReadSwitch(1) == 1 && FA_ReadSwitch(1) == 0)
            botstate = 4;
        }
    }
    return 0;
}

void LineCounting(){
        if (FA_ReadLine(0) < 25){ //(FA_ReadLine(0) < 10 || FA_ReadLine(1) < 60)
                FA_DelayMillis(200);
                TotalLines++;
        }
        else if (FA_ReadIR(2) > 512){
            FA_Backwards(12);
            LineModulus(TotalLines);
        }
    }

void LineModulus(){
    if(TotalLines % 2 == 1){ // counted even lines
        FA_Right(90);
        startTime = FA_ClockMS(); 
        // goes left
        botstate = 3;
    }
    else if(TotalLines % 2 == 0){ // counted odd lines
        FA_Left(90);
        startTime = FA_ClockMS();
        // goes right
        botstate = 2;
    }
}

void DanceFinal(){
    FA_LCDClear();
    FA_LCDPrint("Dance Start", 11, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_SetMotors(50,46);
    FA_PlayNote(1000,200);
    FA_Right(180);
    FA_PlayNote(2000,200);
    FA_Left(180);
    
    int i;
    for (i = 0; i < 8; i++){ // led light display
        FA_LEDOn(i);
        FA_DelayMillis(250);
        FA_LEDOff(i);
    }
    FA_PlayNote(3000,200);
    FA_PlayNote(2000,200);
    FA_PlayNote(890,200);
    unsigned long endTime = FA_ClockMS();
    unsigned long Time = endTime - startTime;
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The time was", 12, 20, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(Time, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The distance", 12, 20, 5, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("travelled was", 13, 20, 15, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(distance, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    botstate = 0;
}

void LeftWall(){
    FA_LCDPrint("Left Wall", 9, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDClear();
    
    if(FA_ReadIR(2) > 1037){
        FA_Backwards(12);
        FA_Right(90);
        Moving();
        directioncount = directioncount + 1;
        FA_SetMotors(25,23);
        FA_LCDPrint("Back", 4, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if(FA_ReadIR(1) < 177 && FA_ReadIR(0) < 177){
        FA_Forwards(72);
        FA_Left(90);
        Moving();
        directioncount = directioncount + 1;
        //FA_SetMotors(25,23);
        FA_SetMotors(25,19);
        FA_Forwards(80);
        turncount = turncount + 1;
        FA_LCDPrint("turn R", 6, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(0) < 450){
        //FA_SetMotors(25,23);
        FA_SetMotors(24,22);
        FA_LCDPrint("go right", 8, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(0) > 1600 || (FA_ReadIR(1) > 2037 && FA_ReadIR(1) < 2999)){
        //FA_SetMotors(25,23);
        FA_SetMotors(23,22);
        FA_LCDPrint("go left", 7, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(1) >= 2999){ //hit the box
        //FA_SetMotors(25,22);
        FA_SetMotors(19,5);
        FA_LCDPrint("hitbox", 6, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (botY == 0 && botX == 0){ // for when it reaches point A
        FA_Left(90);
        Moving();
        FA_SetMotors(25,23); // going straight forward
        FA_LCDPrint("dance time", 10, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
        botstate = 4;
    }
    else if (turncount == 5){ // for when it reaches point A
        FA_Left(90);
        Moving();
        FA_SetMotors(14,12); // going straight forward
        FA_LCDPrint("dance time", 10, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
        botstate = 4;
    }
    else {
        FA_SetMotors(25,23); // going straight forward
        FA_LCDPrint("Forward", 7, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
}

void RightWall(){
    FA_LCDPrint("right Wall", 10, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDClear();
    
    if(FA_ReadIR(2) > 1037){
        FA_Backwards(12);
        Moving();
        directioncount = directioncount + 1;
        FA_Left(90);
        FA_SetMotors(25,23);
        FA_LCDPrint("Back", 4, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if(FA_ReadIR(3) < 177 && FA_ReadIR(4) < 177){
        FA_Forwards(72);
        turncount = turncount + 1;
        Moving();
        directioncount = directioncount + 1;
        FA_Right(90);
        FA_SetMotors(20,23);
        FA_Forwards(80);
        FA_LCDPrint("turn L", 6, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(4) < 450){
        //FA_SetMotors(25,23);
        FA_SetMotors(24,20);
        FA_LCDPrint("go left", 7, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(4) > 1600 || (FA_ReadIR(3) > 2037 && FA_ReadIR(3) < 2999)){
        //FA_SetMotors(25,23);
        FA_SetMotors(23,21);
        FA_LCDPrint("go right", 8, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (FA_ReadIR(3) >= 2999){ //hit the box
        //FA_SetMotors(25,22);
        FA_SetMotors(5,19);
        FA_LCDPrint("hitbox", 6, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
    else if (botY == 0 && botX == 0){ // for when it reaches point A
        FA_Right(90);
        Moving();
        FA_SetMotors(25,23); // going straight forward
        FA_LCDPrint("dance time", 10, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
        botstate = 4;
    }
    else if (turncount == 5){ // for when it reaches point A
        FA_Right(90);
        Moving();
        FA_SetMotors(14,12); // going straight forward
        FA_LCDPrint("dance time", 10, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
        botstate = 4;
    }
    else {
        FA_SetMotors(25,23); // going straight forward
        FA_LCDPrint("Forward", 7, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(60);
    }
}

void DistanceCalc(){
    distance = ((FA_ReadEncoder(1)+FA_ReadEncoder(1)/2));
    totalDistance = totalDistance + distance;
}


void Moving(){
    unsigned short Wheeldistance = ((FA_ReadEncoder(1)+FA_ReadEncoder(1)/2));
    if (directioncount > 4){
        directioncount = 1;
    }
    else if (directioncount == 1){
        direction = 'F';//forward
        botY = botY + Wheeldistance;
    }
    else if (directioncount == 2){
        direction = 'R'; //right
        botX = botX + Wheeldistance;
    }
    else if (directioncount == 3){
        direction = 'L'; //left
        botY = botY - Wheeldistance;
    }
    else if (directioncount == 4){
        direction = 'B'; //back
        botX = botX - Wheeldistance;
    }
}



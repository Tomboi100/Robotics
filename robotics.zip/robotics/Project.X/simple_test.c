
#include "allcode_api.h"    

int main()
{
    FA_RobotInit();         
    FA_LCDBacklight(50);    //Switch on backlight (half brightness)
    FA_LCDPrint("Hello There", 11, 20, 25, FONT_NORMAL, LCD_OPAQUE);//Opening message
    FA_DelayMillis(1000);   //Pause 1 sec

    while(1)    
    {   
        //Start
        FA_SetMotors(61, 9);
        unsigned long starttime = FA_ClockMS();
        int linecount = 0;
        
        int distance = wallFollowing(linecount);
        dance(starttime, distance);
       
        /*
        FA_LCDClear();  // Clear display
        // Display left and right wheel encoder values
        //FA_LCDNumber(FA_ReadEncoder(CHANNEL_LEFT), 0, 0, FONT_NORMAL, LCD_OPAQUE);
        //FA_LCDNumber(FA_ReadEncoder(CHANNEL_RIGHT), 40, 0, FONT_NORMAL, LCD_OPAQUE);

        // Display battery reading
        //FA_LCDNumber(FA_ReadBattery(), 0, 8, FONT_NORMAL, LCD_OPAQUE);

        // Display left and right line sensors
        FA_LCDNumber(FA_ReadLine(CHANNEL_LEFT), 0, 16, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(FA_ReadLine(CHANNEL_RIGHT), 80, 16, FONT_NORMAL, LCD_OPAQUE);
        
        if(FA_ReadSwitch(0) == 1)   // If left button pressed
            FA_PlayNote(1200,200);  // play a low note
        if(FA_ReadSwitch(1) == 1)   // If right button pressed
            FA_PlayNote(2200,200);  // play a high note
        
        FA_DelayMillis(100);    // Pause 0.1 sec
        */
    }
    
    return 0; 
}

void dance(unsigned long starttime, int distance){
    FA_SetMotors(61, 9);
    FA_Forwards(50);
    FA_PlayNote(1000,200);
    FA_Right(180);
    FA_Forwards(50);
    FA_PlayNote(2000,200);
    FA_Left(180);
    FA_Forwards(50);
    int i;
    for (i = 0; i < 8; i++){
        FA_LEDOn(i);
        FA_DelayMillis(250);
        FA_LEDOff(i);
    }
    FA_PlayNote(3000,200);
    unsigned long endTime = FA_ClockMS();
    unsigned long Time = endTime - starttime;
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The time was", 12, 20, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(Time, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The distance travelled was", 26, 20, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(distance, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
}

int wallFollowing(int linecount){
    int distance = FA_CompassInit();
    FA_SetMotors(61, 9);
    
    //if(linecount % 2 = 2){}
    FA_Forwards(50);
    if(FA_ReadIR(2) > 600){ //front sensor
        FA_Backwards(20);
        FA_Right(65);
        while(FA_ReadIR(1) > 600){ //LEFT
            FA_Forwards(50);
        }
        FA_Left(65);
        }
        
    return distance;
}

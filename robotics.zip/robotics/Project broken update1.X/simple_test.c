
#include "allcode_api.h"
unsigned short ls1Rblack = 0; //line sensor values for black and white strips
unsigned short ls1Rwhite = 0;
unsigned short ls2Lblack = 0;
unsigned short ls2Lwhite = 0;
int botX = 0;
int botY = 0;
int distance = 0;
int linecount = 0;
int linemodulus = 0;

int main()
{
    FA_RobotInit();         
    FA_LCDBacklight(50);    //Switch on backlight (half brightness)
    FA_LCDPrint("Hello There", 11, 20, 25, FONT_NORMAL, LCD_OPAQUE);//Opening message
    FA_DelayMillis(1000);//Pause 1 sec
    FA_SetMotors(61, 9);
    FA_LCDClear();

    while(1)    
    {   
        //Start
        FA_Forwards(50);
        linecount = LineCounting();
        FA_LCDNumber(linecount, 20, 15, FONT_NORMAL, LCD_OPAQUE);
        if(linecount >= 3){
            break;  
        }
    }
    
    linemodulus = LineModulus(linecount);//modulus to determine if its even or not
        
    unsigned long starttime;
    switch (linemodulus){
        case 0:
            starttime = FA_ClockMS(); //starts the clock
            distance = wallFollowing('r', distance); //starts wall following right
            break;
        case 1:
            starttime = FA_ClockMS(); //starts the clock
            distance = wallFollowing('l', distance); //starts wall following left
            break;        
        }
    //dance(starttime, distance);
    
    return 0; 
}

void dance(unsigned long starttime, int distance){
    FA_SetMotors(61, 9);
    FA_Forwards(50);
    distance++50;
    FA_PlayNote(1000,200);
    FA_Right(180);
    FA_Forwards(50);
    distance++50;
    FA_PlayNote(2000,200);
    FA_Left(180);
    FA_Forwards(50);
    distance++50;
    int i;
    for (i = 0; i < 8; i++){
        FA_LEDOn(i);
        FA_DelayMillis(250);
        FA_LEDOff(i);
    }
    FA_PlayNote(3000,200);
    unsigned long endTime = FA_ClockMS();
    unsigned long Time = endTime - starttime;
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The time was", 12, 20, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(Time, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The distance", 12, 20, 5, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("travelled was", 13, 20, 15, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(distance, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
}

int wallFollowing(char direction, int distance){
    FA_CompassInit();
    FA_SetMotors(61, 9);
    FA_Forwards(50);
    distance++50;
    switch(direction){
        case 'r':
            if(FA_ReadIR(2) > 600){ //front sensor
                FA_Backwards(20);
                FA_Right(65);
                while(FA_ReadIR(1) > 600){//LEFT
                    FA_Forwards(50);
                    }
                FA_Left(65);
                }
            break;
            
        case 'l':
            if(FA_ReadIR(2) > 600){ //front sensor
                FA_Backwards(20);
                FA_Left(65);
                int i;
                for(i = 0; i < 4; i++){
                    while(FA_ReadIR(5) > 600){//LEFT
                    FA_Forwards(50);
                    }
                FA_Right(65);   
                }
                }
            break;
    }  
    return distance;
}

int LineCounting(){
    //unsigned short rightls = FA_ReadLine(1);
    //unsigned short leftls = FA_ReadLine(0); 
        
    if (FA_ReadLine(1) < 10 || FA_ReadLine(0) < 10){
        FA_DelayMillis(250);
        linecount = linecount + 1;
    }
    return linecount;
}

int LineModulus(int linecount){
    linemodulus = linecount % 2; //modulus to determine if its even or not
    return linemodulus;
}
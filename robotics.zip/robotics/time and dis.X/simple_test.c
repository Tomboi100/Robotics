
#include "allcode_api.h"    // MUST include this to define robot functions

int main()
{
    FA_RobotInit();         // MUST call this before any other robot functions
    
    FA_LCDBacklight(50);    // Switch on backlight (half brightness)
    FA_LCDPrint("Hello", 5, 20, 25, FONT_NORMAL, LCD_OPAQUE);     // Say hi!
    FA_DelayMillis(1000);   // Pause 1 sec
    int distance = 0;

    while(1)           
    { 
        FA_LCDPrint("Start", 5, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelaySecs(2);
        FA_Forwards(50);
        distance = distance + 50;
        unsigned long starttime = FA_ClockMS();
        FA_DelaySecs(4);
        unsigned long endTime = FA_ClockMS();
        unsigned long Time = endTime - starttime;
        FA_DelaySecs(2);
        FA_LCDClear();
        FA_LCDPrint("The time was", 12, 20, 10, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(Time, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelaySecs(2);
        FA_LCDClear();
        FA_LCDPrint("The distance", 12, 20, 5, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDPrint("travelled was", 13, 20, 15, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(distance, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        FA_DelaySecs(2);
        FA_LCDClear();
    }


        /*
        FA_LCDClear();  // Clear display
        // Display left and right wheel encoder values
        FA_LCDNumber(FA_ReadEncoder(CHANNEL_LEFT), 0, 0, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(FA_ReadEncoder(CHANNEL_RIGHT), 40, 0, FONT_NORMAL, LCD_OPAQUE);

        // Display battery reading
        FA_LCDNumber(FA_ReadBattery(), 0, 8, FONT_NORMAL, LCD_OPAQUE);

        // Display left and right line sensors
        FA_LCDNumber(FA_ReadLine(CHANNEL_LEFT), 0, 16, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(FA_ReadLine(CHANNEL_RIGHT), 80, 16, FONT_NORMAL, LCD_OPAQUE);
        
        if(FA_ReadSwitch(0) == 1)   // If left button pressed
            FA_PlayNote(1200,200);  // play a low note
        if(FA_ReadSwitch(1) == 1)   // If right button pressed
            FA_PlayNote(2200,200);  // play a high note
        
        FA_DelayMillis(100);    // Pause 0.1 sec
        
        int i;
        for (i = 0; i < 8; i++) {       // Loop over all 8 IR sensors
            if (FA_ReadIR(i) > 600) {   // If obstacle, light corresponding LED
                FA_LEDOn(i);
            }
            else {
                FA_LEDOff(i);           // else switch LED off
            }
        }
         */
    
    return 0; // Actually, we should never get here...
}


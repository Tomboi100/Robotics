
#include "allcode_api.h"
void dance(unsigned long starttime);
char wallFollowing(char direction, int distance);
int LineCounting();
int LineModulus(int linecount);
void moveforward(int value);
void moveleft(int value);
void moveright(int value);
void moveback(int value);

unsigned short ls1Rblack = 0; //line sensor values for black and white strips
unsigned short ls1Rwhite = 0;
unsigned short ls2Lblack = 0;
unsigned short ls2Lwhite = 0;
int botX = 0;
int botY = 0;
int distance = 0;
int linecount = 0;
int linemodulus = 0;
unsigned long starttime;

int main()
{
    FA_RobotInit();         
    FA_LCDBacklight(50);    //Switch on backlight (half brightness)
    FA_LCDPrint("Hello There", 11, 20, 25, FONT_NORMAL, LCD_OPAQUE);//Opening message
    FA_DelayMillis(1000);//Pause 1 sec
    FA_SetMotors(61, 9);
    FA_LCDClear();

    while(1)    
    {   
        //Start
        moveforward(50);
        static int botstate = 1;
        switch (botstate){
            case 1:
                //Linecount
                linecount = LineCounting();
                FA_LCDNumber(linecount, 20, 15, FONT_NORMAL, LCD_OPAQUE);
                if(linecount >= 3){
                    botstate = 2;
                    break;  
                    }
                break;
            case 2:
                //wallfollowing
                linemodulus = LineModulus(linecount);//modulus to determine if its even or not
                char orientation;
                if(linemodulus == 0){
                    orientation = 'r'; //starts wall following right
                    break;
                }
                else if(linemodulus == 1){
                    orientation = 'l'; //starts wall following left
                    break;
                }
                starttime = FA_ClockMS(); //starts the clock
                distance = wallFollowing(orientation, distance);//starts wall following with orientation
                botstate = 3;
                break;
            case 3:
                //dance
                dance(starttime);
                break;
        }
       
    }
    return 0; 
}

void dance(unsigned long starttime){
    FA_SetMotors(61, 9);
    moveforward(50);
    FA_PlayNote(1000,200);
    FA_Right(180);
    moveforward(50);
    FA_PlayNote(2000,200);
    FA_Left(180);
    moveforward(50);
    int i;
    for (i = 0; i < 8; i++){
        FA_LEDOn(i);
        FA_DelayMillis(250);
        FA_LEDOff(i);
    }
    FA_PlayNote(3000,200);
    unsigned long endTime = FA_ClockMS();
    unsigned long Time = endTime - starttime;
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The time was", 12, 20, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(Time, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
    FA_LCDPrint("The distance", 12, 20, 5, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("travelled was", 13, 20, 15, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(distance, 20, 25, FONT_NORMAL, LCD_OPAQUE);
    FA_DelaySecs(2);
    FA_LCDClear();
}

char wallFollowing(char direction, int distance){
    FA_CompassInit();
    FA_SetMotors(61, 9);
    moveforward(50);
    switch(direction){
        case 'r':
            if(FA_ReadIR(2) > 600){ //front sensor
                FA_Backwards(20);
                FA_Right(65);
                while(FA_ReadIR(1) > 600){//LEFT
                    moveforward(50);
                    }
                FA_Left(65);
                }
            break;
            
        case 'l':
            if(FA_ReadIR(2) > 600){ //front sensor
                FA_Backwards(20);
                FA_Left(65);
                int i;
                for(i = 0; i < 4; i++){
                    while(FA_ReadIR(5) > 600){//LEFT
                    moveforward(50);
                    }
                FA_Right(65);   
                }
                }
            break;
    }  
    return distance;
}

int LineCounting(){
    //unsigned short rightls = FA_ReadLine(1);
    //unsigned short leftls = FA_ReadLine(0); 
        
    if (FA_ReadLine(1) < 10 || FA_ReadLine(0) < 10){ //change
        FA_DelayMillis(200); // change
        linecount = linecount + 1;
    }
    return linecount;
}

int LineModulus(int linecount){
    linemodulus = linecount % 2; //modulus to determine if its even or not
    return linemodulus;
}

void moveforward(int value){
    FA_Forwards(value);
    distance = distance+value;
    botY= botY+value;
}

void moveleft(int value){
    FA_Forwards(value);
    distance = distance+value;
    botX= botX-value;
}

void moveright(int value){
    FA_Forwards(value);
    distance = distance+value;
    botX= botX+value;
}

void moveback(int value){
    FA_Forwards(value);
    distance = distance+value;
    botY= botY-value;
}




#include "allcode_api.h"    // MUST include this to define robot functions
int linecount = 0;

int main()
{
    FA_RobotInit();         // MUST call this before any other robot functions
    
    FA_LCDBacklight(50);    // Switch on backlight (half brightness)
    FA_LCDPrint("Start", 5, 20, 25, FONT_NORMAL, LCD_OPAQUE);     // Say hi!
    FA_DelayMillis(1000);   // Pause 1 sec
    int distance = 0;
    FA_SetMotors(61, 9);
    FA_LCDClear();
    
    while(1)           
    {
        FA_Forwards(50);
        linecount = LineCounting();
        FA_LCDNumber(linecount, 20, 15, FONT_NORMAL, LCD_OPAQUE);
    }

    
    return 0;
}

int LineCounting(){
    //unsigned short rightls = FA_ReadLine(1);
    //unsigned short leftls = FA_ReadLine(0); 
        
    if (FA_ReadLine(1) < 10 || FA_ReadLine(0) < 10){
        FA_DelayMillis(500);
        linecount = linecount + 1;
    }
    return linecount;
}


/*
 * File:   main.c
 * Author: std36
 *
 * Created on 22 March 2022, 15:03
 */


#include "allcode_api.h"
void LineCounter();
void LeftOrRight(int lineCount);
void Dance();
void FinalDisplay(int totalTime, int totalDistance);
void WallFollowingLeft();
void WallFollowingRight();

int lineCount;
int totalTime;
int totalDistance;
int state = 2;

int main(void) {
    FA_RobotInit();         
    FA_LCDBacklight(50);   
    FA_LCDPrint("Hello", 5, 20, 25, FONT_NORMAL, LCD_OPAQUE);   
    FA_LCDClear();

    while(1){
        switch(state){
            case 1:
                FA_SetMotors(20,30);
                LineCounter();
                FA_LCDNumber(lineCount, 20, 25, FONT_NORMAL, LCD_OPAQUE);
                break;
            case 2:
                WallFollowingLeft();
                break;
            case 3:
                WallFollowingRight();
                break;
        }
    }
    return 0;
}

void LineCounter(){
        if (FA_ReadLine(0) < 10 || FA_ReadLine(1) < 40){
            FA_DelayMillis(200);
            lineCount++;
        }
        else if (FA_ReadIR(2) > 1037){
            FA_Backwards(100);
            LeftOrRight(lineCount);
        }
    }

void LeftOrRight(int lineCount){
    if(lineCount % 2 == 0){
        FA_Left(90);
        state = 2;
    }
    else{
        FA_Right(90);
        //state = 3;
    }
}

void Dance(){
    FA_Left(30);
    FA_Right(60);
    FA_Left(30);
    FA_Right(180);
    
}

void FinalDisplay(int totalTime, int totalDistance){
    FA_LCDClear();
    //FA_LCDPrint("--------------------", 20, 127, 5, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("Reached goal!", 13, 10, 30, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("Distance (cm)", 14, 10, 20, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint("Time (sec)", 10, 10, 10, FONT_NORMAL, LCD_OPAQUE);
    //FA_LCDPrint("--------------------", 20, 5, 5, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint(":", 1, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDPrint(":", 1, 10, 23, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(totalDistance, 10, 38, FONT_NORMAL, LCD_OPAQUE);
    FA_LCDNumber(totalTime, 10, 28, FONT_NORMAL, LCD_OPAQUE);
}

void WallFollowingLeft(){
    if (FA_ReadIR(4) < 2804){
        FA_SetMotors(60,60);
        FA_LCDClear();
        FA_LCDPrint("Nudge right", 11, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    }
    else if (FA_ReadIR(4) > 3000){
        FA_SetMotors(50,70);
        FA_LCDClear();
        FA_LCDPrint("Nudge left", 10, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    }
    else if(FA_ReadIR(4) < 706 && FA_ReadIR(5) >= 2804){
        FA_Forwards(100);
        FA_Left(90);
        FA_SetMotors(50,60);
        FA_LCDClear();
        FA_LCDPrint("Turn left", 9, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    }
    else if(FA_ReadIR(2) > 1037){
        FA_Backwards(100);
        FA_Right(90);
        FA_SetMotors(50,60);
        FA_LCDClear();
        FA_LCDPrint("Back", 4, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    }
    else {
        FA_SetMotors(50,60);
        FA_LCDClear();
        FA_LCDPrint("Straight", 8, 10, 33, FONT_NORMAL, LCD_OPAQUE);
    }
}

void WallFollowingRight(){
    if (FA_ReadIR(0) < 2804){
        FA_SetMotors(40,50);
    }
    else if (FA_ReadIR(0) > 3000){
        FA_SetMotors(60,50);
    }
    else if(FA_ReadIR(0) < 706 && FA_ReadIR(7) >= 2804){
        FA_Forwards(100);
        FA_Right(90);
        FA_SetMotors(50,60);
    }
    else if(FA_ReadIR(2) > 1037){
        FA_Backwards(100);
        FA_Left(90);
        FA_SetMotors(50,60);
    }
    else {
        FA_SetMotors(50,60);
    }
}
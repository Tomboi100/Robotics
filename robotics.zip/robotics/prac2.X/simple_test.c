/* Simple skeleton test program for in-robot API */

#include "allcode_api.h"    // MUST include this to define robot functions

int main()
{
    FA_RobotInit();         // MUST call this before any other robot functions
    
    FA_LCDBacklight(50);    // Switch on backlight (half brightness)
    FA_LCDPrint("hello", 15, 20, 25, FONT_NORMAL, LCD_OPAQUE);     // Say hi!
    FA_DelayMillis(1000);// Pause 1 sec
    FA_LCDClear();

    while(1)            // Execute this loop as long as robot is running
    {       // (this is equivalent to Arduino loop() function
        int a = 5;
        int irnum = FA_ReadIR(a);
        FA_LCDNumber(irnum, 20, 20, FONT_NORMAL, LCD_OPAQUE);
        FA_DelayMillis(1000);
        FA_LCDClear();
       
        /*
        //obsstical avoidence
        FA_SetMotors(61, 9);
        FA_Forwards(50);
        if(FA_ReadIR(2) > 600)  //front
        {
            FA_Backwards(20);
            FA_Right(65);
            while(FA_ReadIR(1) > 600){ //LEFT
                FA_Forwards(50);
            }
            FA_Left(65);
        }
        
         FA_SetMotors(61, 9);
        //FA_Forwards(50);
        //FA_LCDPrint(FA_ReadIR(2), 2, 20, 25, FONT_NORMAL, LCD_OPAQUE);
        // Drive forward
      
        if(FA_ReadIR(1) > 600)  // Check front left IR
        {
            FA_Backwards(50);   // Dodge right if obstacle
            FA_Right(30);      
        }
        
        if(FA_ReadIR(2) > 600)  //front
        {
            FA_Backwards(50);
        }
   
        if(FA_ReadIR(3) > 600)  // Check front right IR
        {
            FA_Backwards(50);   // Dodge left if obstacle
            FA_Left(30);     
        }
        */
        /*
        FA_LCDClear();  // Clear display
        // Display left and right wheel encoder values
        //FA_LCDNumber(FA_ReadEncoder(CHANNEL_LEFT), 0, 0, FONT_NORMAL, LCD_OPAQUE);
        //FA_LCDNumber(FA_ReadEncoder(CHANNEL_RIGHT), 40, 0, FONT_NORMAL, LCD_OPAQUE);

        // Display battery reading
        //FA_LCDNumber(FA_ReadBattery(), 0, 8, FONT_NORMAL, LCD_OPAQUE);

        // Display left and right line sensors
        FA_LCDNumber(FA_ReadLine(CHANNEL_LEFT), 0, 16, FONT_NORMAL, LCD_OPAQUE);
        FA_LCDNumber(FA_ReadLine(CHANNEL_RIGHT), 80, 16, FONT_NORMAL, LCD_OPAQUE);
        
        if(FA_ReadSwitch(0) == 1)   // If left button pressed
            FA_PlayNote(1200,200);  // play a low note
        if(FA_ReadSwitch(1) == 1)   // If right button pressed
            FA_PlayNote(2200,200);  // play a high note
        
        FA_DelayMillis(100);    // Pause 0.1 sec
        
        int i;
        for (i = 0; i < 8; i++) {       // Loop over all 8 IR sensors
            if (FA_ReadIR(i) > 600) {   // If obstacle, light corresponding LED
                FA_LEDOn(i);
            }
            else {
                FA_LEDOff(i);           // else switch LED off
            }
        }*/
    }
    
    return 0; 
}

